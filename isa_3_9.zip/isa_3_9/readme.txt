Isa 3.9 NNUE
---------------------------------------------------------------------------------------------------------
Here is the new release of Isa chess engine 

Isa is a bitboard chess engine , written from scratch . 
It is the bitboard port from my mailbox one (the best was 2.0.83 version , 2330 elo CCRL)
The hce bitboard version was about at the same level as 2.0.83 

Now it is NNUE , it has a /768-256)x2-1 net , trained on 1.6billion  Isa self play positions 
The net is embedded in the binary 

---------------------------------------------------------------------------------------------------------
Changes : (not very detailled as we want to keep them a little bit secret , sorry) 

SEE (static exchange evaluator) algorithm  bug fix
Killers moves implemented
More reductions 

Book : I've created a small book for Isa (in txt format , fens positions) the file is ggg.txt . 
TO USE ISA WITH HER BOOK , PLEASE YOU MUST RENAME this ggg.txt file to final_book.txt

I want to give a big thanks to Martin Sedlak (Cheng developper) for his great work , and with big 
interest to my engine. He did some interresting tests matches , too 
Also , great thanks to Andres Valverde who ran Isa's gauntlet for CCRL and , 
Great thanks to Graham Banks , running many funny tournaments .
Thanks to Lars for some tests .

Some tests give to 3.9 version an approximate elo CCRL of 3075 

Enjoy
