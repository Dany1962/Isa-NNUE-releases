here is Isa hce only for Alex Brunetti

If you want to use it with her own book you must rename the file ggg.txt to final_book.txt

Enjoy

Dany
