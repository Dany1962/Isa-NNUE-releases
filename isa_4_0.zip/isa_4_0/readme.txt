Isa 4.0 NNUE
---------------------------------------------------------------------------------------------------------
Here is the new release of Isa chess engine 

Isa is a bitboard chess engine , written from scratch . 
It is the bitboard port from my mailbox one (the best was 2.0.83 version , 2330 elo CCRL)
The hce bitboard version was about at the same level as 2.0.83 

Now it is NNUE , it has a (768-256)x2-1 net , trained on 2.1billion position from Isa self play 
The net is embedded in the binary 
The particular work of the NNUE version was done entirely by Martin Sedlak (Cheng autor)

---------------------------------------------------------------------------------------------------------
Changes : (not very detailled as we want to keep them a little bit secret , sorry) 

	New net trained with 2.1b positions 
	Fix pv promotions
	tt probe in qs
	More aggressive futility pruning (depth 0-5 instead of depth 0-3)
	Aspiration windows
	Clean ups

Book : I've created a small book for Isa (in txt format , fens positions) the file is ggg.txt . 
TO USE ISA WITH HER BOOK , PLEASE YOU MUST RENAME this ggg.txt file to final_book.txt

I want to give a big thanks to Martin Sedlak (Cheng developper) for his great work , and with big 
interest to my engine. He did some interresting tests matches , too 
Also , great thanks to Andres Valverde who ran Isa's gauntlet for CCRL and , 
Great thanks to Graham Banks , running many funny tournaments .
Thanks to Lars for some tests .

The tests give to 4.0 version an improvement of +80 elo vs 3.9 (fast tc 8" + 0.08" increment)
So an expected Elo of around 3120  

Enjoy
